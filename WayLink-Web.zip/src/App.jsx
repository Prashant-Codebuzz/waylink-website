// Css
import './css/App.scss'
import { Route, Routes } from 'react-router-dom'
// Scroll-To-Top
import ScrollToTop from './components/scroll-to-top/ScrollToTop'
// LayOut
import LayOut from './components/layout/Layout'
// Home
import Home from './pages/home/Home'

function App() {

    return (
        <>

            {/* Scroll-To-Top */}
            <ScrollToTop />

            <Routes>
                <Route element={<LayOut />}>
                    {/* Home */}
                    <Route path='/' element={<Home />} />
                </Route>
            </Routes>

        </>
    )
}

export default App;
