import Agent from '../../assets/images/home/agent.png';

// ------ Country ------  
export const CountryData= [
    "Canada", "Belgium", "France", "Iceland", "Denmark", "Germany", "Australia", "Canada", "Belgium", "France"
]


// ------ Our-Consultancy ------  
export const OurConsultancyItems= [
    
]


// ------ Agent ------  
export const AgentData= [
    { image : Agent, name: "Sendra Lily", experience: 5 },
    { image : Agent, name: "Sendra Lily", experience: 5 },
    { image : Agent, name: "Sendra Lily", experience: 5 },
    { image : Agent, name: "Sendra Lily", experience: 5 },
]   